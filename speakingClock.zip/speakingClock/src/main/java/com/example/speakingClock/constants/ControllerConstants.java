package com.example.speakingClock.constants;

public class ControllerConstants {

    private ControllerConstants(){}

    public static final String SPEAKING_CLOCK="/speaking-clock";
}
